#include "WeatherService.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

/* ============================================================
 * SETTINGS
 * ============================================================ */
static const char* WIFI_SSID = "grig";
static const char* WIFI_PASS = "magnetic";

static const char* API_KEY = "07108cf067a5fdf5aa26dce75354400f";
static const char* CITY    = "Kharkiv";
static const char* UNITS   = "metric";
static const char* LANG    = "uk";

static const unsigned long UPDATE_INTERVAL =
    15UL * 60UL * 1000UL;

/* ============================================================
 * PUBLIC
 * ============================================================ */
void WeatherService::begin() {
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASS);

    lastUpdateMs = 0;
    wifiOk = false;
    current.valid = false;

    WLOG("[Weather] service started");
}

bool WeatherService::isWiFiOk() const {
    return wifiOk;
}

const WeatherData& WeatherService::data() const {
    return current;
}

void WeatherService::update() {

    static wl_status_t lastWiFiStatus = WL_IDLE_STATUS;
    static unsigned long lastHeartbeat = 0;

    wl_status_t st = WiFi.status();

    // --- Wi-Fi status change log ---
    if (st != lastWiFiStatus) {
        Serial.print("[WiFi] status = ");
        Serial.println(st);
        lastWiFiStatus = st;
    }

    // --- Heartbeat (раз в 10 сек) ---
    if (millis() - lastHeartbeat > 10000) {
        Serial.print("[Weather] alive, wifi=");
        Serial.println(st == WL_CONNECTED ? "OK" : "NO");
        lastHeartbeat = millis();
    }

    if (st != WL_CONNECTED) {
        wifiOk = false;
        current.valid = false;
        return;
    }

    wifiOk = true;

    // --- timing ---
    unsigned long now = millis();
    if (lastUpdateMs != 0 && (now - lastUpdateMs) < UPDATE_INTERVAL)
        return;

    lastUpdateMs = now;

    WLOG("[Weather] updating...");
    fetchCurrent();
    fetchForecast();
}

/* ============================================================
 * CURRENT WEATHER
 * ============================================================ */
void WeatherService::fetchCurrent() {

    HTTPClient http;
    String url =
        String("http://api.openweathermap.org/data/2.5/weather?q=") +
        CITY + "&appid=" + API_KEY +
        "&units=" + UNITS +
        "&lang=" + LANG;

    http.begin(url);
    int code = http.GET();

    if (code != 200) {
        current.valid = false;
        http.end();
        WLOG("[Weather] current FAILED");
        return;
    }

    DynamicJsonDocument doc(2048);
    deserializeJson(doc, http.getString());
    http.end();

    current.temp     = doc["main"]["temp"];
    current.feels    = doc["main"]["feels_like"];
    current.humidity = doc["main"]["humidity"];
    current.wind     = doc["wind"]["speed"];
    current.icon     = mapIcon(doc["weather"][0]["icon"].as<String>());
    current.valid    = true;

    WLOG("[Weather] current OK");
}

/* ============================================================
 * FORECAST
 * ============================================================ */
void WeatherService::fetchForecast() {

    HTTPClient http;
    String url =
        String("http://api.openweathermap.org/data/2.5/forecast?q=") +
        CITY + "&appid=" + API_KEY +
        "&units=" + UNITS +
        "&lang=" + LANG;

    http.begin(url);
    if (http.GET() != 200) {
        http.end();
        WLOG("[Weather] forecast FAILED");
        return;
    }

    DynamicJsonDocument doc(8192);
    deserializeJson(doc, http.getString());
    http.end();

    for (int i = 0; i < 3; i++) {
        current.forecast[i].tMin =  100;
        current.forecast[i].tMax = -100;
    }

    for (int i = 0; i < 24; i++) {
        int day = i / 8;
        if (day > 2) break;

        float t = doc["list"][i]["main"]["temp"];
        current.forecast[day].tMin =
            min(current.forecast[day].tMin, t);
        current.forecast[day].tMax =
            max(current.forecast[day].tMax, t);

        current.forecast[day].icon =
            mapIcon(doc["list"][i]["weather"][0]["icon"].as<String>());
    }

    WLOG("[Weather] forecast OK");
}

/* ============================================================
 * ICON MAP
 * ============================================================ */
WeatherIcon WeatherService::mapIcon(const String& icon) {
    if (icon.startsWith("01")) return ICON_CLEAR;
    if (icon.startsWith("02") || icon.startsWith("03") || icon.startsWith("04"))
        return ICON_CLOUDS;
    if (icon.startsWith("09") || icon.startsWith("10"))
        return ICON_RAIN;
    if (icon.startsWith("13")) return ICON_SNOW;
    return ICON_UNKNOWN;
}