#pragma once
#include <Arduino.h>

/*
 ============================================================
  WeatherService
  - Wi-Fi + OpenWeather
  - логирование по событиям
 ============================================================
*/

// ===== LOG LEVEL =====
#define LOG_WEATHER 1   // 0 = OFF, 1 = INFO

#if LOG_WEATHER
  #define WLOG(x) Serial.println(x)
#else
  #define WLOG(x)
#endif

enum WeatherIcon : uint8_t {
    ICON_CLEAR,
    ICON_CLOUDS,
    ICON_RAIN,
    ICON_SNOW,
    ICON_UNKNOWN
};

struct DailyForecast {
    float tMin = NAN;
    float tMax = NAN;
    WeatherIcon icon = ICON_UNKNOWN;
};

struct WeatherData {
    float temp = NAN;
    float feels = NAN;
    float humidity = NAN;
    float wind = NAN;
    WeatherIcon icon = ICON_UNKNOWN;

    DailyForecast forecast[3];
    bool valid = false;
};

class WeatherService {
public:
    void begin();
    void update();

    const WeatherData& data() const;
    bool isWiFiOk() const;

private:
    WeatherData current;
    unsigned long lastUpdateMs = 0;
    bool wifiOk = false;

    void fetchCurrent();
    void fetchForecast();
    WeatherIcon mapIcon(const String& icon);
};