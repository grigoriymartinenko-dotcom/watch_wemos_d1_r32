#pragma once
#include <Arduino.h>

// ===== UI THEME =====
struct Theme {
    uint16_t bg;
    uint16_t time;
    uint16_t text;
};

// RGB565 helpers
static constexpr uint16_t GREY       = 0x7BEF;
static constexpr uint16_t DARK_RED   = 0x8000;

// ===== THEMES =====
static const Theme DAY_THEME = {
    .bg   = ST77XX_BLACK,
    .time = ST77XX_WHITE,
    .text = GREY
};

static const Theme NIGHT_THEME = {
    .bg   = ST77XX_BLACK,
    .time = ST77XX_RED,
    .text = DARK_RED
};