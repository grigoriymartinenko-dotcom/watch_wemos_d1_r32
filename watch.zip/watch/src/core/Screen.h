#pragma once
#include <Adafruit_ST7735.h>

/*
 * Screen — базовый класс всех экранов
 * ==================================
 * • Не знает про кнопки GPIO
 * • Не знает про ScreenManager
 * • Только логика и UI
 *
 * Каждый экран:
 *  - begin()  → вызывается при активации
 *  - update() → вызывается каждый loop()
 *  - onUp / onDown / onOk / onBack
 *  - drawButtons() → подписи кнопок внизу
 */

class Screen {
public:
    virtual ~Screen() {}

    // Активировали экран
    virtual void begin() {}

    // Основная отрисовка
    virtual void update() {}

    // Кнопки
    virtual void onUp() {}
    virtual void onDown() {}
    virtual void onOk() {}
    virtual void onBack() {}

    /*
     * Подписи кнопок
     * --------------
     * По умолчанию одинаковые для всех экранов
     * Можно переопределить в наследнике
     */
    virtual void drawButtons(Adafruit_ST7735& tft) {
        tft.setTextSize(1);
        tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);

        int y = tft.height() - 10;

        tft.setCursor(5, y);    tft.print("UP");
        tft.setCursor(45, y);   tft.print("OK");
        tft.setCursor(85, y);   tft.print("BACK");
        tft.setCursor(125, y);  tft.print("DOWN");
    }
};