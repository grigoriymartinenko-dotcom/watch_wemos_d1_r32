#pragma once
#include "core/Screen.h"
#include <Adafruit_ST7735.h>

/*
 * ScreenManager
 * =============
 * • Хранит активный экран
 * • Передаёт ему кнопки
 * • Вызывает update + drawButtons
 *
 * ВСЯ навигация — ТОЛЬКО здесь
 */

class ScreenManager {
public:
    void set(Screen* screen) {
        _current = screen;
        if (_current) _current->begin();
    }

    void update(Adafruit_ST7735& tft) {
        if (!_current) return;

        _current->update();
        _current->drawButtons(tft);
    }

    void onUp()   { if (_current) _current->onUp(); }
    void onDown() { if (_current) _current->onDown(); }
    void onOk()   { if (_current) _current->onOk(); }
    void onBack() { if (_current) _current->onBack(); }

    Screen* active() { return _current; }

private:
    Screen* _current = nullptr;
};