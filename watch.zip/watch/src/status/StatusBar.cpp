#include "status/StatusBar.h"

static uint16_t COL_BG   = 0x0000;
static uint16_t COL_OK   = 0x07E0;
static uint16_t COL_WARN = 0xF800;
static uint16_t COL_DIM  = 0x7BEF;

StatusBar::StatusBar(Adafruit_ST7735& t)
: tft(t) {}

void StatusBar::setWiFi(bool ok) {
    wifi = ok;
}

void StatusBar::setNight(bool n) {
    night = n;
}

void StatusBar::invalidate() {
    forceRedraw = true;
}

void StatusBar::draw() {

    if (!forceRedraw &&
        wifi == prevWifi &&
        night == prevNight) {
        return;
    }

    forceRedraw = false;
    prevWifi  = wifi;
    prevNight = night;

    int x = tft.width() - 12;
    tft.fillRect(x, 0, 12, tft.height(), COL_BG);

    drawWiFi();
    drawNight();
}

void StatusBar::drawWiFi() {

    int x = tft.width() - 8;
    int y = 6;

    uint16_t c = wifi ? COL_OK : COL_WARN;

    tft.fillCircle(x, y, 2, c);
    tft.drawCircle(x, y + 5, 4, c);
}

void StatusBar::drawNight() {

    int x = tft.width() - 8;
    int y = 22;

    // днём — тёмно-серая, ночью — яркая
    uint16_t c = night ? 0xFFFF : 0x7BEF;

    // контур луны
    tft.drawCircle(x, y, 3, c);

    if (night) {
        tft.fillCircle(x, y, 2, c);
    }
}