#pragma once
#include <Adafruit_ST7735.h>

/*
 ============================================================
  StatusBar — правый статус-бар (WiFi / Night)
 ============================================================
*/
class StatusBar {
public:
    explicit StatusBar(Adafruit_ST7735& tft);

    void setWiFi(bool ok);
    void setNight(bool night);

    // вызывать при смене экрана
    void invalidate();

    void draw();

private:
    Adafruit_ST7735& tft;

    bool wifi  = false;
    bool night = false;

    bool prevWifi  = false;
    bool prevNight = false;

    bool forceRedraw = true;

    void drawWiFi();
    void drawNight();
};