#pragma once

/*
 * ClockNightMode
 * ==============
 * Централизованное управление ночным режимом
 * Используется всеми экранами
 */

enum class ClockNightMode {
    DAY,
    NIGHT,
    AUTO
};

// Глобальное состояние (одно на весь проект)
extern ClockNightMode clockNightMode;