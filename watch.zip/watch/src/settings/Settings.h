#pragma once
#include "settings/ClockNightMode.h"

/*
 ============================================================
  Settings — единое хранилище глобальных настроек
 ============================================================
*/
namespace Settings {

    // Night mode controller
    extern ClockNightMode night;

    // Sensor values (DHT)
    extern float temp;
    extern float hum;
}