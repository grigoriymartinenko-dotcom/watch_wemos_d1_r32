#include "settings/Settings.h"

/*
 ============================================================
  Реальные определения переменных Settings
 ============================================================
*/
namespace Settings {

    ClockNightMode night;

    float temp = 0.0f;
    float hum  = 0.0f;
}