#include "settings/ClockNightMode.h"

/*
 * Значение по умолчанию
 * AUTO — лучший вариант для часов
 */
ClockNightMode clockNightMode = ClockNightMode::AUTO;