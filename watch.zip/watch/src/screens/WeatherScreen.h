#pragma once
#include "core/Screen.h"
#include "core/ScreenManager.h"

/*
 * WeatherScreen
 * =============
 * Экран погоды
 */

class WeatherScreen : public Screen {
public:
    WeatherScreen(Adafruit_ST7735& tft,
                  ScreenManager& sm,
                  Screen* clock)
        : _tft(tft), _sm(sm), _clock(clock) {}

    void begin() override {
        _tft.fillScreen(ST77XX_BLACK);
    }

    void update() override {
        // Отрисовка погоды (у тебя уже есть)
    }

    // BACK → часы
    void onBack() override {
        _sm.set(_clock);
    }

private:
    Adafruit_ST7735& _tft;
    ScreenManager& _sm;
    Screen* _clock;
};