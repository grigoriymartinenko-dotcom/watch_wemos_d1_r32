#include "screens/SettingsScreen.h"

SettingsScreen::SettingsScreen(Adafruit_ST7735& t)
: tft(t) {}

void SettingsScreen::begin() {
    selected = 0;
    editMode = false;
    exitRequested = false;
    needRedraw = true;
}

void SettingsScreen::onUp() {
    if (selected > 0) {
        selected--;
        needRedraw = true;
    }
}

void SettingsScreen::onDown() {
    if (selected < ITEMS_COUNT - 1) {
        selected++;
        needRedraw = true;
    }
}

void SettingsScreen::onOk() {
    editMode = !editMode;
    needRedraw = true;
}

void SettingsScreen::onBack() {
    if (editMode) {
        editMode = false;
        needRedraw = true;
    } else {
        exitRequested = true;
    }
}

bool SettingsScreen::shouldExit() const {
    return exitRequested;
}

void SettingsScreen::clearExitFlag() {
    exitRequested = false;
}

void SettingsScreen::draw() {

    if (!needRedraw) return;
    needRedraw = false;

    tft.fillScreen(0x0000);

    tft.setTextSize(2);
    tft.setTextColor(0xFFFF);
    tft.setCursor(10, 5);
    tft.print("SETTINGS");

    int startY = 30;
    int rowH = 18;

    for (uint8_t i = 0; i < ITEMS_COUNT; i++) {
        drawItem(i, startY + i * rowH, i == selected);
    }
}

void SettingsScreen::drawItem(uint8_t index, int y, bool active) {

    tft.setTextSize(1);
    tft.setTextColor(active ? 0xFFE0 : 0xFFFF);
    tft.setCursor(10, y);

    switch (index) {
        case 0: tft.print("Night mode"); break;
        case 1: tft.print("Brightness"); break;
        case 2: tft.print("About"); break;
    }

    tft.setCursor(90, y);
    tft.print(valueForItem(index));
}

const char* SettingsScreen::valueForItem(uint8_t index) const {
    switch (index) {
        case 0: return "AUTO";
        case 1: return "100%";
        default: return "";
    }
}