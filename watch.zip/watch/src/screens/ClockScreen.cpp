/*
 * ClockScreen.cpp
 * ===============
 * Реализация главного экрана часов
 */

#include "screens/ClockScreen.h"

#include <Fonts/FreeSansBold18pt7b.h>
#include <Fonts/FreeSans9pt7b.h>

/* ============================================================
 * Конструктор
 * ============================================================
 */
ClockScreen::ClockScreen(Adafruit_ST7735& tft,
                         RtcDS1302<ThreeWire>& rtc,
                         StatusBar& statusBar)
    : _tft(tft),
      _rtc(rtc),
      _statusBar(statusBar) {
}

/* ============================================================
 * begin()
 * ============================================================
 * Вызывается один раз при входе на экран
 */
void ClockScreen::begin() {
    drawStatic();
    _lastMinute = -1;
    _lastSecond = -1;
}

/* ============================================================
 * update()
 * ============================================================
 * Основной цикл экрана
 */
void ClockScreen::update() {
    RtcDateTime now = _rtc.GetDateTime();

    // Статус-бар (WiFi / NTP / etc)
    _statusBar.update(now);

    // Обновляем только если реально изменилось
    if (now.Minute() != _lastMinute) {
        drawTime(now);
        drawWeekday(now);
        drawSensors();
        _lastMinute = now.Minute();
    }

    if (now.Second() != _lastSecond) {
        drawSeconds(now);
        _lastSecond = now.Second();
    }
}

/* ============================================================
 * drawStatic()
 * ============================================================
 * Фон и неизменяемые элементы
 */
void ClockScreen::drawStatic() {
    _tft.fillScreen(ST77XX_BLACK);

    // Разделительная линия под статус-баром
    _tft.drawFastHLine(0, 12, _tft.width(), ST77XX_DARKGREY);
}

/* ============================================================
 * drawWeekday()
 * ============================================================
 */
void ClockScreen::drawWeekday(const RtcDateTime& dt) {
    static const char* days[] = {
        "SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"
    };

    _tft.setFont(&FreeSans9pt7b);
    _tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);

    _tft.setCursor(5, 32);
    _tft.print(days[dt.DayOfWeek()]);
}

/* ============================================================
 * drawTime()
 * ============================================================
 */
void ClockScreen::drawTime(const RtcDateTime& dt) {
    char buf[6];
    snprintf(buf, sizeof(buf), "%02d:%02d", dt.Hour(), dt.Minute());

    _tft.setFont(&FreeSansBold18pt7b);
    _tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);

    _tft.setCursor(10, 70);
    _tft.print(buf);
}

/* ============================================================
 * drawSeconds()
 * ============================================================
 */
void ClockScreen::drawSeconds(const RtcDateTime& dt) {
    char buf[3];
    snprintf(buf, sizeof(buf), "%02d", dt.Second());

    _tft.setFont(&FreeSans9pt7b);
    _tft.setTextColor(ST77XX_YELLOW, ST77XX_BLACK);

    _tft.setCursor(110, 70);
    _tft.print(buf);
}

/* ============================================================
 * drawTempIcon()
 * ============================================================
 */
void ClockScreen::drawTempIcon(int x, int y) {
    _tft.drawCircle(x, y, 3, ST77XX_RED);
    _tft.drawFastVLine(x, y + 3, 6, ST77XX_RED);
}

/* ============================================================
 * drawHumIcon()
 * ============================================================
 */
void ClockScreen::drawHumIcon(int x, int y) {
    _tft.fillCircle(x, y, 3, ST77XX_BLUE);
}

/* ============================================================
 * drawSensors()
 * ============================================================
 */
void ClockScreen::drawSensors() {
    _tft.setFont(&FreeSans9pt7b);
    _tft.setTextColor(ST77XX_CYAN, ST77XX_BLACK);

    // TEMP
    drawTempIcon(10, 110);
    _tft.setCursor(20, 115);
    _tft.print("--.-C");

    // HUM
    drawHumIcon(70, 110);
    _tft.setCursor(80, 115);
    _tft.print("--%");
}