#pragma once
#include <Adafruit_ST7735.h>

#include "core/Screen.h"
#include "core/ScreenManager.h"
#include "settings/ClockNightMode.h"

/*
 * SettingsScreen
 * ==============
 * Меню настроек
 */

class SettingsScreen : public Screen {
public:
    SettingsScreen(Adafruit_ST7735& tft,
                   ScreenManager& sm,
                   Screen* clock)
        : _tft(tft), _sm(sm), _clock(clock) {}

    void begin() override {
        drawMenu();
    }

    void onUp() override {
        if (_selected > 0) _selected--;
        drawMenu();
    }

    void onDown() override {
        if (_selected < 0) return;
    }

    void onOk() override {
        if (_selected == 0) {
            cycleNightMode();
            drawMenu();
        }
    }

    void onBack() override {
        _sm.set(_clock);
    }

    // Свои подписи кнопок
    void drawButtons(Adafruit_ST7735& tft) override {
        tft.setTextSize(1);
        tft.setTextColor(ST77XX_WHITE, ST77XX_BLACK);

        int y = tft.height() - 10;
        tft.setCursor(5, y);   tft.print("UP");
        tft.setCursor(45, y);  tft.print("OK");
        tft.setCursor(85, y);  tft.print("BACK");
    }

private:
    void cycleNightMode() {
        if (clockNightMode == ClockNightMode::DAY)
            clockNightMode = ClockNightMode::NIGHT;
        else if (clockNightMode == ClockNightMode::NIGHT)
            clockNightMode = ClockNightMode::AUTO;
        else
            clockNightMode = ClockNightMode::DAY;
    }

    void drawMenu() {
        _tft.fillScreen(ST77XX_BLACK);
        _tft.setTextSize(1);

        _tft.setCursor(10, 20);
        _tft.setTextColor(ST77XX_YELLOW);
        _tft.print("Night Mode:");
        _tft.print(
            clockNightMode == ClockNightMode::DAY   ? " DAY" :
            clockNightMode == ClockNightMode::NIGHT ? " NIGHT" :
                                                       " AUTO"
        );
    }

    Adafruit_ST7735& _tft;
    ScreenManager& _sm;
    Screen* _clock;

    uint8_t _selected = 0;
};