#ifndef WATCH_OOP_SCREENS_TEMP_GRAPH_SCREEN_H
#define WATCH_OOP_SCREENS_TEMP_GRAPH_SCREEN_H

#include <Adafruit_ST7735.h>
#include "core/Screen.h"
#include "ui/Theme.h"
#include "sensors/TempHistory.h"

class TempGraphScreen : public Screen {
public:
  TempGraphScreen(Adafruit_ST7735& tft, TempHistory& hist);

  void onEnter() override;
  void draw() override;

private:
  Adafruit_ST7735& tft;
  TempHistory& history;
  const Theme* theme = &DAY_THEME;

  bool needRedraw = true;

  void drawFrame();
  void drawGraph();
};

#endif // WATCH_OOP_SCREENS_TEMP_GRAPH_SCREEN_H