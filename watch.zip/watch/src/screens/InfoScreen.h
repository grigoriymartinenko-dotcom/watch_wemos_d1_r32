#pragma once
#include <Arduino.h>
#include <Adafruit_ST7735.h>
#include "core/Screen.h"

class InfoScreen : public Screen {
public:
  explicit InfoScreen(Adafruit_ST7735& display);

  void onEnter() override;
  void draw() override;

private:
  Adafruit_ST7735& tft;

  // ===== timing =====
  unsigned long lastUpdate = 0;

  // ===== cached values =====
  String lastIP = "";
  int lastRSSI = -999;
  unsigned long lastUptime = 0;

  bool needRedraw = true;

  // ===== layout helpers =====
  int valueX = 70;   // будет пересчитан автоматически
};