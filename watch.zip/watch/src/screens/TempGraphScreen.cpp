#include "TempGraphScreen.h"

#define GRAPH_X 10
#define GRAPH_Y 20
#define GRAPH_W 140
#define GRAPH_H 80

// серый цвет (замена ST77XX_DARKGREY)
#define COLOR_GRID 0x7BEF

TempGraphScreen::TempGraphScreen(Adafruit_ST7735& d, TempHistory& h)
  : tft(d), history(h) {}

void TempGraphScreen::onEnter() {
  tft.fillScreen(theme->bg);
  needRedraw = true;
}

void TempGraphScreen::draw() {
  if (!needRedraw || !history.hasData()) return;
  needRedraw = false;

  drawFrame();
  drawGraph();
}

void TempGraphScreen::drawFrame() {
  tft.drawRect(GRAPH_X, GRAPH_Y, GRAPH_W, GRAPH_H, COLOR_GRID);

  tft.setTextSize(1);
  tft.setTextColor(ST77XX_WHITE);
  tft.setCursor(GRAPH_X, GRAPH_Y - 10);
  tft.print("Temp (1h)");
}

void TempGraphScreen::drawGraph() {
  float tMin = history.min();
  float tMax = history.max();
  if (tMax - tMin < 0.5f) tMax = tMin + 0.5f;

  uint8_t len = history.length();
  if (len < 2) return;

  for (uint8_t i = 1; i < len; i++) {
    float t1 = history.get(i - 1);
    float t2 = history.get(i);

    int x1 = GRAPH_X + (i - 1) * GRAPH_W / (TempHistory::SIZE - 1);
    int x2 = GRAPH_X + i * GRAPH_W / (TempHistory::SIZE - 1);

    int y1 = GRAPH_Y + GRAPH_H -
      (t1 - tMin) * GRAPH_H / (tMax - tMin);
    int y2 = GRAPH_Y + GRAPH_H -
      (t2 - tMin) * GRAPH_H / (tMax - tMin);

    tft.drawLine(x1, y1, x2, y2, ST77XX_GREEN);
  }
}