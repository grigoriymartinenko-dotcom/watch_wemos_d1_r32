#pragma once

/*
 * ClockScreen.h
 * =============
 * Главный экран часов
 *
 * ВАЖНО:
 * - Этот файл полностью синхронизирован с ClockScreen.cpp
 * - НИЧЕГО не удалено из логики
 * - Только объявления, которые реально реализованы в .cpp
 */

#include <Adafruit_ST7735.h>
#include <RtcDS1302.h>

#include "core/Screen.h"
#include "status/StatusBar.h"
#include "settings/ClockNightMode.h"

class ClockScreen : public Screen {
public:
    /*
     * Конструктор
     * -----------
     * tft        — дисплей ST7735
     * rtc        — DS1302
     * statusBar  — верхняя статусная строка (WiFi / NTP / etc)
     */
    ClockScreen(Adafruit_ST7735& tft,
                RtcDS1302<ThreeWire>& rtc,
                StatusBar& statusBar);

    // Вызывается при активации экрана
    void begin() override;

    // Вызывается каждый loop()
    void update() override;

private:
    /* ================== ОТРИСОВКА ================== */

    // Полная статическая отрисовка (фон, разделители)
    void drawStatic();

    // День недели (ПН, ВТ, ...)
    void drawWeekday(const RtcDateTime& dt);

    // Основное время (ЧЧ:ММ)
    void drawTime(const RtcDateTime& dt);

    // Секунды
    void drawSeconds(const RtcDateTime& dt);

    // Иконки температуры / влажности
    void drawTempIcon(int x, int y);
    void drawHumIcon(int x, int y);

    // Блок датчиков (t°, влажность)
    void drawSensors();

    /* ================== ДАННЫЕ ================== */

    Adafruit_ST7735&        _tft;
    RtcDS1302<ThreeWire>&   _rtc;
    StatusBar&              _statusBar;

    // Для оптимизации перерисовки
    int _lastMinute  = -1;
    int _lastSecond  = -1;
};