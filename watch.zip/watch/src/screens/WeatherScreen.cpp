#include "screens/WeatherScreen.h"

WeatherScreen::WeatherScreen(Adafruit_ST7735& t)
: tft(t) {}

void WeatherScreen::begin() {
    exitRequested = false;
    needRedraw = true;
}

void WeatherScreen::onBack() {
    exitRequested = true;
}

bool WeatherScreen::shouldExit() const {
    return exitRequested;
}

void WeatherScreen::clearExitFlag() {
    exitRequested = false;
}

void WeatherScreen::draw() {

    if (!needRedraw) return;
    needRedraw = false;

    tft.fillScreen(0x0000);

    tft.setTextSize(2);
    tft.setTextColor(0xFFFF);
    tft.setCursor(10, 30);
    tft.print("WEATHER");

    tft.setTextSize(1);
    tft.setCursor(10, 60);
    tft.print("NO DATA");
}