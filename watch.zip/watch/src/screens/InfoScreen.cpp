#include "InfoScreen.h"
#include <WiFi.h>

static const uint16_t COLOR_DIVIDER = 0x7BEF; // тёмно-серый
static const uint8_t LINE_H = 10;

InfoScreen::InfoScreen(Adafruit_ST7735& display)
  : tft(display) {}

void InfoScreen::onEnter() {
  tft.fillScreen(ST77XX_BLACK);

  tft.setTextSize(1);
  tft.setTextColor(ST77XX_WHITE);

  // ----- header -----
  tft.setCursor(5, 5);
  tft.print("INFO");
  tft.drawFastHLine(0, 15, 160, COLOR_DIVIDER);

  // ----- labels -----
  tft.setCursor(5, 25);
  tft.print("IP:");

  tft.setCursor(5, 45);
  tft.print("RSSI:");

  tft.setCursor(5, 65);
  tft.print("UPTIME:");

  // ----- calculate value column X dynamically -----
  int16_t x1, y1;
  uint16_t w, h;
  tft.getTextBounds("UPTIME:", 0, 0, &x1, &y1, &w, &h);
  valueX = 5 + w + 6;   // 6px отступ после подписи

  // ----- reset cache to force redraw -----
  lastIP = "";
  lastRSSI = -999;
  lastUptime = 0;
  lastUpdate = 0;
  needRedraw = true;
}

void InfoScreen::draw() {
  unsigned long now = millis();

  // ===== update data once per second =====
  if (now - lastUpdate >= 1000) {
    lastUpdate = now;

    String ip = WiFi.isConnected() ? WiFi.localIP().toString() : "-";
    int rssi = WiFi.isConnected() ? WiFi.RSSI() : 0;
    unsigned long uptime = now / 1000;

    if (ip != lastIP || rssi != lastRSSI || uptime != lastUptime) {
      lastIP = ip;
      lastRSSI = rssi;
      lastUptime = uptime;
      needRedraw = true;
    }
  }

  if (!needRedraw) return;
  needRedraw = false;

  // ===== clear value areas only =====
  tft.fillRect(valueX, 25, 160 - valueX - 5, LINE_H, ST77XX_BLACK);
  tft.fillRect(valueX, 45, 160 - valueX - 5, LINE_H, ST77XX_BLACK);
  tft.fillRect(valueX, 65, 160 - valueX - 5, LINE_H, ST77XX_BLACK);

  // ===== draw values =====
  tft.setCursor(valueX, 25);
  tft.print(lastIP);

  tft.setCursor(valueX, 45);
  tft.print(lastRSSI);
  tft.print(" dBm");

  tft.setCursor(valueX, 65);
  tft.print(lastUptime);
  tft.print(" s");
}