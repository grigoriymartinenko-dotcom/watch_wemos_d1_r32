#include <Arduino.h>
#include <SPI.h>
#include <WiFi.h>

#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <RtcDS1302.h>

#include "core/ScreenManager.h"
#include "screens/ClockScreen.h"
#include "screens/WeatherScreen.h"
#include "screens/SettingsScreen.h"

#include "status/StatusBar.h"
#include "sensors/TempSensor.h"
#include "settings/Settings.h"

// ================= TFT =================
#define TFT_CS   5
#define TFT_DC   2
#define TFT_RST  4
Adafruit_ST7735 tft(TFT_CS, TFT_DC, TFT_RST);

// ================= RTC =================
#define RTC_CLK 14
#define RTC_DAT 27
#define RTC_RST 26
ThreeWire myWire(RTC_DAT, RTC_CLK, RTC_RST);
RtcDS1302<ThreeWire> rtc(myWire);

// ================= BUTTONS =================
#define BTN_UP    17
#define BTN_DOWN  16
#define BTN_OK    22
#define BTN_BACK  21

// ================= DHT =================
#define DHT_PIN 25
TempSensor tempSensor(DHT_PIN);

// ================= WIFI =================
const char* WIFI_SSID = "grig";
const char* WIFI_PASS = "magnetic";

// ================= UI =================
StatusBar statusBar(tft);

ClockScreen    clockScreen(tft, rtc, statusBar);
WeatherScreen  weatherScreen(tft);
SettingsScreen settingsScreen(tft);

ScreenManager screenManager;

// =================================================
void setup() {

    Serial.begin(115200);

    // --- TFT ---
    tft.initR(INITR_BLACKTAB);
    tft.setRotation(1);
    tft.fillScreen(0x0000);

    // --- RTC ---
    rtc.Begin();

    // --- DHT ---
    tempSensor.begin();

    // --- Buttons ---
    pinMode(BTN_UP,    INPUT_PULLUP);
    pinMode(BTN_DOWN,  INPUT_PULLUP);
    pinMode(BTN_OK,    INPUT_PULLUP);
    pinMode(BTN_BACK,  INPUT_PULLUP);

    // --- WiFi ---
    WiFi.mode(WIFI_STA);
    WiFi.begin(WIFI_SSID, WIFI_PASS);

    // --- Start screen ---
    screenManager.set(&clockScreen);
}

// =================================================
void loop() {

    // ---------- BUTTONS ----------
    if (!digitalRead(BTN_UP)) {
        screenManager.onUp();
        delay(180);
    }

    if (!digitalRead(BTN_DOWN)) {
        screenManager.onDown();

        // Clock → Weather
        if (screenManager.active() == &clockScreen) {
            screenManager.set(&weatherScreen);
        }
        delay(180);
    }

    if (!digitalRead(BTN_OK)) {
        screenManager.onOk();

        // Clock → Settings
        if (screenManager.active() == &clockScreen) {
            screenManager.set(&settingsScreen);
        }
        delay(180);
    }

    if (!digitalRead(BTN_BACK)) {
        screenManager.onBack();

        // любой экран → Clock
        if (screenManager.active() != &clockScreen) {
            screenManager.set(&clockScreen);
        }
        delay(180);
    }

    // ---------- SENSORS ----------
    tempSensor.update();
    if (tempSensor.isValid()) {
        Settings::temp = tempSensor.getTemp();
        Settings::hum  = tempSensor.getHum();
    }

    // ---------- DRAW ----------
    screenManager.draw();

    // ---------- STATUS BAR ----------
    statusBar.setWiFi(WiFi.status() == WL_CONNECTED);
    statusBar.setNight(
        Settings::night.isActive(rtc.GetDateTime().Hour())
    );
    statusBar.draw();
}