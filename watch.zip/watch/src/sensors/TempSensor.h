#pragma once
#include <Arduino.h>
#include <DHT.h>

/*
 ============================================================
  TempSensor — DHT11 (температура + влажность)
 ============================================================
*/
class TempSensor {
public:
    explicit TempSensor(uint8_t pin);

    void begin();
    void update();

    // === ГЕТТЕРЫ ===
    bool  isValid() const { return valid; }
    float getTemp() const { return temp; }
    float getHum()  const { return hum;  }

private:
    DHT dht;

    unsigned long lastRead = 0;

    float temp  = 0.0f;
    float hum   = 0.0f;
    bool  valid = false;
};