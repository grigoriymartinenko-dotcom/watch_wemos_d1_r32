#ifndef WATCH_OOP_SENSORS_TEMP_HISTORY_H
#define WATCH_OOP_SENSORS_TEMP_HISTORY_H

#include <Arduino.h>

class TempHistory {
public:
  static const uint8_t SIZE = 60;

  void update(float temp);
  bool hasData() const { return count > 0; }

  float min() const;
  float max() const;
  float get(uint8_t i) const;

  uint8_t length() const { return count; }

private:
  float data[SIZE];
  uint8_t head = 0;
  uint8_t count = 0;
  unsigned long lastStore = 0;
};

#endif // WATCH_OOP_SENSORS_TEMP_HISTORY_H