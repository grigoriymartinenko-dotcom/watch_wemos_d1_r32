#include "TempSensor.h"

#define DHT_TYPE DHT11

TempSensor::TempSensor(uint8_t pin)
  : dht(pin, DHT_TYPE) {}

void TempSensor::begin() {
  dht.begin();
}

void TempSensor::update() {
  if (millis() - lastRead < 2000) return;
  lastRead = millis();

  float h = dht.readHumidity();
  float t = dht.readTemperature();

  if (isnan(h) || isnan(t)) {
    valid = false;
    return;
  }

  hum = h;
  temp = t;
  valid = true;
}