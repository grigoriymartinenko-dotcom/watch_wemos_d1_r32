#include "TempHistory.h"

void TempHistory::update(float temp) {
  if (millis() - lastStore < 60000) return; // 1 минута
  lastStore = millis();

  data[head] = temp;
  head = (head + 1) % SIZE;

  if (count < SIZE) count++;
}

float TempHistory::get(uint8_t i) const {
  if (i >= count) return 0;
  int idx = (head + SIZE - count + i) % SIZE;
  return data[idx];
}

float TempHistory::min() const {
  float m = data[0];
  for (uint8_t i = 1; i < count; i++)
    if (data[i] < m) m = data[i];
  return m;
}

float TempHistory::max() const {
  float m = data[0];
  for (uint8_t i = 1; i < count; i++)
    if (data[i] > m) m = data[i];
  return m;
}